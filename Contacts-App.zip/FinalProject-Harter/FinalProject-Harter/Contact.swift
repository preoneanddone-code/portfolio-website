//
//  Contact.swift
//  FinalProject-Harter
//
//  Created by Preston Harter on 4/13/26.
//

import Foundation

class Contact: NSObject, NSCoding {
    var symbol: String
    var name: String
    var contactType: String
    var pronouns: String
    var phoneNumber: String
    var email: String
    var notes: String
    static var documentsPath = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first
    static let archiveURL: URL = (documentsPath!.appendingPathComponent(PropertyKey.emoji))
    
    
    init(symbol: String, name: String, contactType: String, pronouns: String, phoneNumber: String, email: String, notes: String) {
        self.symbol = symbol
        self.name = name
        self.contactType = contactType
        self.pronouns = pronouns
        self.phoneNumber = phoneNumber
        self.email = email
        self.notes = notes
    }
    
    struct PropertyKey {
        static let symbol = "symbol"
        static let name = "name"
        static let contactType = "contactType"
        static let pronouns = "pronouns"
        static let phoneNumber = "phoneNumber"
        static let email = "email"
        static let notes = "notes"
        static let emoji = "emoji"
    }
    
    required convenience init?(coder aDecoder: NSCoder) {
        guard let symbol = aDecoder.decodeObject(forKey: PropertyKey.symbol) as? String, let name = aDecoder.decodeObject(forKey: PropertyKey.name) as? String, let contactType = aDecoder.decodeObject(forKey: PropertyKey.contactType) as? String, let pronouns = aDecoder.decodeObject(forKey: PropertyKey.pronouns) as? String, let phoneNumber = aDecoder.decodeObject(forKey: PropertyKey.phoneNumber) as? String, let email = aDecoder.decodeObject(forKey: PropertyKey.email) as? String, let notes = aDecoder.decodeObject(forKey: PropertyKey.notes) as? String
        else { return nil }
        
        self.init(symbol: symbol, name: name, contactType: contactType, pronouns: pronouns, phoneNumber: phoneNumber, email: email, notes: notes)
    }
    
    func encode( with aCoder: NSCoder) {
        aCoder.encode(symbol, forKey: PropertyKey.symbol)
        aCoder.encode(name, forKey: PropertyKey.name)
        aCoder.encode(contactType, forKey: PropertyKey.contactType)
        aCoder.encode(pronouns, forKey: PropertyKey.pronouns)
        aCoder.encode(phoneNumber, forKey: PropertyKey.phoneNumber)
        aCoder.encode(email, forKey: PropertyKey.email)
        aCoder.encode(notes, forKey: PropertyKey.notes)
    }
}

extension Contact {
    static func saveToFile (contacts: [Contact]) {
        NSKeyedArchiver.archiveRootObject(contacts, toFile: Contact.archiveURL.path)
    }
    
    static func loadFromFile() -> [Contact]? {
        return NSKeyedUnarchiver.unarchiveObject(withFile: Contact.archiveURL.path) as? [Contact]
    }
    
    static func loadSampleEmojis() -> [Contact] {
        let contacts: [Contact] = [
            Contact(symbol: "👩", name: "Mom", contactType: "Favorites", pronouns: "She/Her", phoneNumber: "+1 (123) 456-7890", email: "mom@gmail.com", notes: "She's my mom!"),
            Contact(symbol: "👨", name: "Dad", contactType: "Favorites", pronouns: "He/Him", phoneNumber: "1 (098) 765-4321", email: "dad@gmail.com", notes: "He's my dad!"),
            Contact(symbol: "👦", name: "Brother", contactType: "Favorites", pronouns: "He/Him", phoneNumber: "1 (555) 555-5555", email: "bro@gmail.com", notes: "He's my brother!"),
            Contact(symbol: "👧", name: "Sister", contactType: "Favorites", pronouns: "She/Her", phoneNumber: "1 (666) 666-6666", email: "sis@gmail.com", notes: "She's my sister!"),
            Contact(symbol: "🧏‍♂️", name: "Best Friend", contactType: "Favorites", pronouns: "They/Them", phoneNumber: "1 (676) 767-6767", email: "dude@outlook.com", notes: "They're dumb as rocks!"),
            Contact(symbol: "🤰", name: "Partner", contactType: "Favorites", pronouns: "They/Them", phoneNumber: "1 (111) 111-1111", email: "partner@gmail.com", notes: "They're perfect")
        ]
        
        return contacts
    }
}
