//
//  ContactTableViewCell.swift
//  FinalProject-Harter
//
//  Created by Preston Harter on 4/13/26.
//

import UIKit

class ContactTableViewCell: UITableViewCell {
    
    @IBOutlet var symbolLabel: UILabel!
    @IBOutlet var nameLabel: UILabel!
    @IBOutlet var phoneLabel: UILabel!

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
    func update(with contact: Contact) {
        symbolLabel.text = contact.symbol
        nameLabel.text = contact.name
        phoneLabel.text = contact.phoneNumber
    }

}
