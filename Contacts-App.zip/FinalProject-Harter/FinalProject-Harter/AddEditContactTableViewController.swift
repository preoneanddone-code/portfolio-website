//
//  AddEditContactTableViewController.swift
//  FinalProject-Harter
//
//  Created by Preston Harter on 4/13/26.
//

import UIKit

class AddEditContactTableViewController: UITableViewController {

    var contact: Contact?

    @IBOutlet var symbolTextField: UITextField!
    @IBOutlet var nameTextField: UITextField!
    @IBOutlet var contactTypeTextField: UITextField!
    @IBOutlet var pronounsTextField: UITextField!
    @IBOutlet var phoneNumberTextField: UITextField!
    @IBOutlet var emailTextField: UITextField!
    @IBOutlet var notesTextField: UITextField!
    @IBOutlet var saveButton: UIBarButtonItem!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        if let contact = contact {
            symbolTextField.text = contact.symbol
            nameTextField.text = contact.name
            contactTypeTextField.text = contact.contactType
            pronounsTextField.text = contact.pronouns
            phoneNumberTextField.text = contact.phoneNumber
            emailTextField.text = contact.email
            notesTextField.text = contact.notes
            title = "Edit Contact"
        } else {
            title = "Add Contact"
        }
        
        updateSaveButtonState()
    }
    
    func updateSaveButtonState() {
        let nameText = nameTextField.text ?? ""
        let contactTypeText = contactTypeTextField.text ?? ""
        let pronounsText = pronounsTextField.text ?? ""
        let phoneNumberText = phoneNumberTextField.text ?? ""
        let emailText = emailTextField.text ?? ""
        let notesText = notesTextField.text ?? ""
        saveButton.isEnabled = containsSingleEmoji(symbolTextField) && !nameText.isEmpty && !contactTypeText.isEmpty && !pronounsText.isEmpty && !phoneNumberText.isEmpty && !emailText.isEmpty && !notesText.isEmpty
    }
    
    @IBAction func textEditingChanged(_ sender: UITextField) {
        updateSaveButtonState()
    }
    
    func containsSingleEmoji(_ textField: UITextField) -> Bool {
        guard let text = textField.text, text.count == 1 else {
            return false
        }
        
        let isCombinedIntoEmoji = text.unicodeScalars.count > 1 && text.unicodeScalars.first?.properties.isEmoji ?? false
        let isEmojiPresentation = text.unicodeScalars.first?.properties.isEmojiPresentation ?? false
        
        return isEmojiPresentation || isCombinedIntoEmoji
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        guard segue.identifier == "saveUnwind" else { return }

        let symbol = symbolTextField.text ?? ""
        let name = nameTextField.text ?? ""
        let contactType = contactTypeTextField.text ?? ""
        let pronouns = pronounsTextField.text ?? ""
        let phoneNumber = phoneNumberTextField.text ?? ""
        let email = emailTextField.text ?? ""
        let notes = notesTextField.text ?? ""
        contact = Contact(symbol: symbol, name: name, contactType: contactType, pronouns: pronouns, phoneNumber: phoneNumber, email: email, notes: notes)
    }

}
