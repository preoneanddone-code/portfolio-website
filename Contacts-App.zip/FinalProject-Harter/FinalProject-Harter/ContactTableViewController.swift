//
//  ContactTableViewController.swift
//  FinalProject-Harter
//
//  Created by Preston Harter on 4/13/26.
//

import UIKit

class ContactTableViewController: UITableViewController {

    var contacts = [Contact]()
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let loadedContacts = Contact.loadFromFile()
        
        if let savedContacts = Contact.loadFromFile(), !savedContacts.isEmpty {
            contacts = savedContacts
        } else {
            contacts = Contact.loadSampleEmojis()
            Contact.saveToFile(contacts: contacts)
        }
        
        navigationItem.leftBarButtonItem = editButtonItem
        tableView.rowHeight = UITableView.automaticDimension
        tableView.estimatedRowHeight = 44.0
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        tableView.reloadData()
    }
    
    @IBSegueAction func addEditContact(_ coder: NSCoder, sender: Any?) -> AddEditContactTableViewController? {
        if let cell = sender as? UITableViewCell, let indexPath = tableView.indexPath(for: cell) {
            let contactToEdit = contacts[indexPath.row]
            return AddEditContactTableViewController(coder: coder)
        } else {
            return AddEditContactTableViewController(coder: coder)
        }
    }
    
    @IBAction func unwindToContactTableView(segue: UIStoryboardSegue) {
        guard segue.identifier == "saveUnwind",
            let sourceViewController = segue.source as? AddEditContactTableViewController,
            let contact = sourceViewController.contact else { return }
        
        if let selectedIndexPath = tableView.indexPathForSelectedRow {
            contacts[selectedIndexPath.row] = contact
            tableView.reloadRows(at: [selectedIndexPath], with: .none)
        } else {
            let newIndexPath = IndexPath(row: contacts.count, section: 0)
            contacts.append(contact)
            tableView.insertRows(at: [newIndexPath], with: .automatic)
        }
        Contact.saveToFile(contacts: contacts)
    }
    
    // MARK: - Table view data source

    override func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if section == 0 {
            return contacts.count
        } else {
            return 0
        }
    }

    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "ContactCell", for: indexPath) as! ContactTableViewCell

        let contact = contacts[indexPath.row]

        cell.update(with: contact)
        cell.showsReorderControl = true

        return cell
    }

    override func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            contacts.remove(at: indexPath.row)
            tableView.deleteRows(at: [indexPath], with: .fade)
        } else if editingStyle == .insert {
        }
        
        Contact.saveToFile(contacts: contacts)
    }

    override func tableView(_ tableView: UITableView, moveRowAt fromIndexPath: IndexPath, to: IndexPath) {
        let movedContact = contacts.remove(at: fromIndexPath.row)
        contacts.insert(movedContact, at: to.row)
        tableView.reloadData()
        Contact.saveToFile(contacts: contacts)
    }
    
    
    override func tableView(_ tableView: UITableView, editingStyleForRowAt indexPath: IndexPath) -> UITableViewCell.EditingStyle {
        return .delete
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "editContact",
           let destination = segue.destination as? AddEditContactTableViewController,
           let indexPath = tableView.indexPathForSelectedRow {
            
            destination.contact = contacts[indexPath.row]
        }
    }
}
