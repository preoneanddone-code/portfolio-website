import os

TempFile = "temperatures_database.txt"
DateFile = "temperature_date_database.txt"

def load_temperatures():
    if os.path.exists(TempFile):
        with open(TempFile, "r") as infile:
            temps = [line.strip() for line in infile.readlines()]
            return temps
    if os.path.exists(DateFile):
        with open(DateFile, "r") as infile:
            dates = [line.strip() for line in infile.readlines()]
            return dates
    TempList = f"{temps}, on {dates}."
    return TempList

def save_temperatures(temperatures):
    with open(TempFile, "w") as outfile:
        for temp in temperatures:
            outfile.write(temp + "\n")
    
    with open(DateFile, "w") as outfile:
       for date in temperatures:
          outfile.write(date + "\n")

def showing_temperature_in_list(temperatures):
    tempDict = {}
    print("The database currently is:")
    if not temperatures:
        print("The Database is Empty")
    else:
        for i, t in enumerate(temperatures, 1):
            tempDict[i] = t
        print(tempDict)
    return tempDict


def pound_removing_temperature_from_list (temperatures, temperature_to_remove):
    tempDict = showing_temperature_in_list(temperatures)
    try:
        confirm_temperature=input(f"You inputed the number: {temperature_to_remove}. "
                                  "Are you sure you would like to remove this temperature from the database? "
                                  "(The temperature will be deletated forever): ").lower()
        if confirm_temperature=="yes":
            tempDict.pop(temperature_to_remove, None)
            temperatures.clear()
            for temp in tempDict.values():
                temperatures.append(temp)
            save_temperatures(temperatures)
            print(f"You removed the temperature for {temperature_to_remove} from the database.")
            showing_temperature_in_list(temperatures)
        else:
            print(f"The temperature for {temperature_to_remove} was not removed from the database.")
            removing_temperature_from_list(temperatures)
    except ValueError:
        print(f"{temperature_to_remove} was not found in the database.")            
        start_remove=input("Would you like to remove a different temperature from the database?: ").lower()
        if "remove" in start_remove or "get rid of" in start_remove or "delete" in start_remove or "yes" in start_remove or "positive" in start_remove:
            removing_temperature_from_list(temperatures)
        else:
            return

def date_removing_temperature_from_list (temperatures, temperature_to_remove):
    try:
        confirm_temperature=input(f"You inputed the date: {temperature_to_remove}. "
                                  f"This will remove the last instance on {temperature_to_remove}. "
                                  "Are you sure you would like to remove this temperature from the database? "
                                  "(The temperature will be deletated forever): ").lower()
        if confirm_temperature=="yes":
            temperatures.reverse()
            temperatures.remove(temperature_to_remove)
            temperatures.reverse()
            save_temperatures(temperatures)
            print(f"You removed the last temperature on {temperature_to_remove} from the database.")
            showing_temperature_in_list(temperatures)
        else:
            print(f"The last temperature on {temperature_to_remove} was not removed from the database.")
            removing_temperature_from_list(temperatures)
    except ValueError:
        print(f"The last temperature on {temperature_to_remove} was not found in the database.")            
        start_remove=input("Would you like to remove a different temperature from the database?: ").lower()
        if "remove" in start_remove or "get rid of" in start_remove or "delete" in start_remove or "yes" in start_remove or "positive" in start_remove:
            removing_temperature_from_list(temperatures)
        else:
            return

def number_removing_temperature_from_list (temperatures, temperature_to_remove):
    try:
        confirm_temperature=input(f"You inputed the temperature: {temperature_to_remove}. "
                                  f"This will remove the last instance of {temperature_to_remove}. "
                                  "Are you sure you would like to remove this temperature from the database? "
                                  "(The temperature will be deletated forever): ").lower()
        if confirm_temperature=="yes":
            temperatures.reverse()
            temperatures.remove(temperature_to_remove)
            temperatures.reverse()
            save_temperatures(temperatures)
            print(f"You removed the last {temperature_to_remove} from the database.")
            showing_temperature_in_list(temperatures)
        else:
            print(f"The last {temperature_to_remove} was not removed from the database.")
            removing_temperature_from_list(temperatures)
    except ValueError:
        print(f"{temperature_to_remove} was not found in the database.")            
        start_remove=input("Would you like to remove a different temperature from the database?: ").lower()
        if "remove" in start_remove or "get rid of" in start_remove or "delete" in start_remove or "yes" in start_remove or "positive" in start_remove:
            removing_temperature_from_list(temperatures)
        else:
            return

def adding_temperature_to_list(temperatures):
  while True:
    temperature_to_add=input("Input the temperature right now (in Fahrenheit): ")
    if "°F" not in temperature_to_add:
        temperature_to_add=temperature_to_add+"°F"
    date_to_add = input(f"What day is it?: (month/day/year) ")
    confirm_temperature=input(f"You inputed {temperature_to_add} as the temperature right now on {date_to_add}. "
                              f"Would you like to add {temperature_to_add} on {date_to_add} to the database?: ").lower()
    if "yes" in confirm_temperature or "confirm" in confirm_temperature or "affermitive" in confirm_temperature:
        temperatures.append(f"{temperature_to_add} on {date_to_add}")
        save_temperatures(temperatures)
        print(f"You added {temperature_to_add} on {date_to_add} to the database.")
        break
    else:
        print(f"{temperature_to_add} on {date_to_add} was not added to the database.")
        start_remove=input("Would you like to add a different temperature to the database?: ").lower()
        if "add" in start_remove or "yes" in start_remove or "positive" in start_remove:
            adding_temperature_to_list
        else:
            return

def removing_temperature_from_list (temperatures):
  while True:
    showing_temperature_in_list(temperatures)
    temperature_to_remove=input("Input the number (use #1, #2, #3), temperature, or date of the temperature you would like to remove: ").lower()
    pound = False
    da = False
    num = False
    if temperature_to_remove == "stop" or temperature_to_remove == "return":
        start(temperatures)
    for i in temperature_to_remove:
        if i == "#":
            pound = True
            pound_removing_temperature_from_list(temperatures, temperature_to_remove)
        elif i == "/":
            da = True
            date_removing_temperature_from_list(temperatures, temperature_to_remove)
        else:
            num = True
            if "°F" not in temperature_to_remove:
                temperature_to_remove=temperature_to_remove+"°F"
            number_removing_temperature_from_list(temperatures, temperature_to_remove)

def start(temperatures):
    temperatures=load_temperatures()
    while True:
        what_to_do=input("Would you like to show the database of temperatures, add to it, "
                         "remove a temperature from the database, or end the program: ").lower()
        if "show" in what_to_do:
            showing_temperature_in_list(temperatures)
        elif "add" in what_to_do:
            adding_temperature_to_list(temperatures)
        elif "remove" in what_to_do or "get rid of" in what_to_do or "delete" in what_to_do:
            removing_temperature_from_list(temperatures)
        elif "end" in what_to_do or "close" in what_to_do:
            confirm_end_of_program=input("Ending the program will save then exit the database. "
                                        "Are you sure you would like to end the program?: ").lower()
            if "yes" in confirm_end_of_program or "positive" in confirm_end_of_program or "sure" in confirm_end_of_program:
                save_temperatures(temperatures)
                print("Temperatures are saved.")
                print("Ending the program now.")
                break
        else:
            print(f"This program could not read {what_to_do}. Please input a word this program can understand.")

def main():
    temperatures=[]
    start(temperatures)

if __name__=="__main__":
    main()
