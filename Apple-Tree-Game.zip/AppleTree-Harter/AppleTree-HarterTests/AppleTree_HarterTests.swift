//
//  AppleTree_HarterTests.swift
//  AppleTree-HarterTests
//
//  Created by Preston Harter on 11/3/25.
//

import Testing
@testable import AppleTree_Harter

struct AppleTree_HarterTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
