//
//  Game.swift
//  AppleTree-Harter
//
//  Created by Preston Harter on 11/5/25.
//

import Foundation

struct Game {
    var word: String
    var incorrectMovesRemaining: Int
}
