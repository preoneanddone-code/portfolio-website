
import UIKit

@MainActor
class StoreItemListTableViewController: UITableViewController {
    
    @IBOutlet var searchBar: UISearchBar!
    @IBOutlet var filterSegmentedControl: UISegmentedControl!
    
    // add item controller property
    
    var items = [StoreItem]()
    let itemController = ItemController()
    var imageLoadTasks: [IndexPath: Task<Void, Never>] = [:]
    
    let queryOptions = ["movie", "song", "software", "ebook"]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
    }
    
    func fetchMatchingItems() {
        
        self.items = []
        self.tableView.reloadData()
        
        guard let text = searchBar.text, !text.isEmpty else { return }
        let searchTerm = text.trimmingCharacters(in: .whitespacesAndNewlines)
        
        guard !searchTerm.isEmpty else { return }
        
        let mediaType = queryOptions[filterSegmentedControl.selectedSegmentIndex]
                
        let searchQuery: [String: String] = [
            "term": searchTerm,
            "entity": mediaType,
            "limit": "15"
        ]
        
        Task {
            do {
                let fetchedItems = try await itemController.fetchItems(matching: searchQuery)
                
                await MainActor.run {
                    self.items = fetchedItems
                    self.tableView.reloadData()
                }
                
            } catch {
                print("Error fetching items:", error)
            }
        }
    }
    
    func configure(cell: ItemCell, forItemAt indexPath: IndexPath) {
        
        let item = items[indexPath.row]
        
        cell.name = item.name
        
        cell.artist = item.artistName
        
        cell.artworkImage = nil
        
        
        guard let artworkURL = item.artworkUrl100 else {
            return
        }
        
        let task = Task {
            do {
                let (data, _) = try await URLSession.shared.data(from: artworkURL)
                
                if let image = UIImage(data: data) {
                    await MainActor.run {
                        cell.artworkImage = image
                    }
                }
            } catch {
                print("Image load error: ", error)
            }
        }
    }
    
    @IBAction func filterOptionUpdated(_ sender: UISegmentedControl) {
        fetchMatchingItems()
    }
    
    
    // MARK: - Table view data source

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        return items.count
    }

    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        imageLoadTasks[indexPath]?.cancel()
        imageLoadTasks[indexPath] = nil
        
        guard let cell = tableView.dequeueReusableCell(withIdentifier: "Item", for: indexPath) as? ItemCell else {
            return UITableViewCell()
        }
        
        configure(cell: cell, forItemAt: indexPath)

        return cell
    }
    
    // MARK: - Table view delegate
    
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        tableView.deselectRow(at: indexPath, animated: true)
    }
    
    override func tableView(_ tableView: UITableView, didEndDisplaying cell: UITableViewCell, forRowAt indexPath: IndexPath) {
        // cancel the image fetching task if we no longer need it
        imageLoadTasks[indexPath]?.cancel()
    }
}

extension StoreItemListTableViewController: UISearchBarDelegate {

    func searchBarSearchButtonClicked(_ searchBar: UISearchBar) {
        
        fetchMatchingItems()
        searchBar.resignFirstResponder()
    }
}

