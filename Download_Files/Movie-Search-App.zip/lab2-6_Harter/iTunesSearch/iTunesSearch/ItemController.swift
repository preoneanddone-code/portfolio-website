import Foundation

struct StoreItem: Decodable {
    let trackName: String?
    let collectionName: String?
    let artistName: String?
    let artworkUrl100: URL?
    
    var name: String {
        return trackName ?? collectionName ?? "Unknown"
    }
}

struct SearchResponse: Decodable {
    let results: [StoreItem]
}

class ItemController {
    func fetchItems(matching query: [String: String]) async throws -> [StoreItem] {
        let baseURL = "https://itunes.apple.com/search"
        var components = URLComponents(string: baseURL)
        
        components?.queryItems = query.map {
            URLQueryItem(name: $0.key, value: $0.value)
        }
        
        guard let url = components?.url else {
            throw URLError(.badURL)
        }
        
        print("Request URL:", url)
        
        let (data, _) = try await URLSession.shared.data(from: url)
        
        let decoder = JSONDecoder()
        let response = try decoder.decode(SearchResponse.self, from: data)
        
        return response.results
    }
}
